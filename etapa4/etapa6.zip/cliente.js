const nomes = prompt('Qual é o seu nome')
let nome = document.getElementById('nomeReal')
//const name = document.getElementById('senha')
nome.innerHTML = `${nomes}`


